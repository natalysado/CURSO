// Selecciona el botón y el body
const button = document.getElementById('beepButton');
const body = document.body;

// Define la función callback
function seEjecutaEnEvento() {
    // Agrega un párrafo al final del body
    body.insertAdjacentHTML('beforeend', '<p>BEEP</p>');
    
    // Cambia el color del body
    body.classList.toggle('color');
}

// Agrega el eventListener al botón
button.addEventListener('click', seEjecutaEnEvento);
