// Selecciona los botones y las imágenes
const btnMoney = document.getElementById('btnMoney');
const btnMiami = document.getElementById('btnMiami');
const btnMaiameee = document.getElementById('btnMaiameee');
const imgMoney = document.getElementById('imgMoney');
const imgMiami = document.getElementById('imgMiami');
const imgMaiameee = document.getElementById('imgMaiameee');

// Agrega event listeners para mostrar/ocultar las imágenes al hacer click en los botones
btnMoney.addEventListener('click', () => {
    imgMoney.classList.toggle('oculto');
});

btnMiami.addEventListener('click', () => {
    imgMiami.classList.toggle('oculto');
});

btnMaiameee.addEventListener('click', () => {
    imgMaiameee.classList.toggle('oculto');
});

// Agrega event listeners para ocultar las imágenes al hacer click sobre ellas
imgMoney.addEventListener('click', () => {
    imgMoney.classList.add('oculto');
});

imgMiami.addEventListener('click', () => {
    imgMiami.classList.add('oculto');
});

imgMaiameee.addEventListener('click', () => {
    imgMaiameee.classList.add('oculto');
});
