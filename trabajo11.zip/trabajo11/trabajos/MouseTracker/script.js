// Selecciona la imagen y el body
const imgSeguidora = document.getElementById('seguidora');
const body = document.querySelector('body');

// Variable para verificar si el mouse está presionado
let mouseDown = false;

// Evento para detectar cuando se presiona el mouse
body.addEventListener('mousedown', () => {
    mouseDown = true;
});

// Evento para detectar cuando se suelta el mouse
body.addEventListener('mouseup', () => {
    mouseDown = false;
});

// Evento para mover la imagen cuando el mouse se mueve
body.addEventListener('mousemove', (event) => {
    if (mouseDown) {
        imgSeguidora.style.top = event.clientY + 'px';
        imgSeguidora.style.left = event.clientX + 'px';
    }
});
