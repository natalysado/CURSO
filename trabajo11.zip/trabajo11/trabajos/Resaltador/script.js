// Selecciona todos los párrafos
const parrafos = document.querySelectorAll('p');

// Recorre todos los párrafos y agrega un eventListener a cada uno
parrafos.forEach(parrafo => {
    parrafo.addEventListener('click', () => {
        parrafo.classList.toggle('resaltado');
    });
});
