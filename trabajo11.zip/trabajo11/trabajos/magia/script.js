// Selecciona el div secreto y la imagen secreta
const divMagia = document.getElementById('magia');
const imgSecreta = document.getElementById('secreta');

// Agrega event listener para ocultar la imagen cuando el mouse pasa sobre el div
divMagia.addEventListener('mouseover', () => {
    imgSecreta.style.display = 'none';
});

// Agrega event listener para mostrar la imagen cuando el mouse sale del div
divMagia.addEventListener('mouseout', () => {
    imgSecreta.style.display = 'block';
});
