// Mapea los colores en español a sus equivalentes en inglés
const colorMap = {
    rojo: 'red',
    azul: 'blue',
    amarillo: 'yellow'
};

// Selecciona el input
const colorInput = document.getElementById('colorInput');

// Agrega un evento keydown al input
colorInput.addEventListener('keydown', (event) => {
    // Verifica si la tecla presionada es Enter
    if (event.key === 'Enter') {
        // Obtiene el valor del input y lo convierte a minúsculas
        const colorValue = event.target.value.toLowerCase();
        // Si el color está en el mapa, cambia el color de fondo
        if (colorMap[colorValue]) {
            document.body.style.backgroundColor = colorMap[colorValue];
        } else {
            alert('Color no válido. Por favor ingresa rojo, azul o amarillo.');
        }
    }

    // Verifica si la tecla presionada es Backspace
    if (event.key === 'Backspace') {
        document.body.style.backgroundColor = 'white';
    }
});

