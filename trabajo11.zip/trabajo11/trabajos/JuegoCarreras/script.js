// Selecciona los autos
const autoRojo = document.getElementById('autoRojo');
const autoAzul = document.getElementById('autoAzul');
const autoVerde = document.getElementById('autoVerde');
const autoAmarillo = document.getElementById('autoAmarillo');

// Acumuladores para la posición de los autos
let posicionRojo = 0;
let posicionAzul = 0;
let posicionVerde = 0;
let posicionAmarillo = 0;

// Puntuación
let puntuacion = 0;

// Ancho de la pista y de los autos
const pista = document.getElementById('pista');
const anchoPista = pista.clientWidth;
const anchoAuto = autoRojo.clientWidth;

// Evento para mover los autos
function moverAutos(event) {
    const tecla = event.key.toLowerCase();
    let mensaje = '';

    if (tecla === 'a') {
        posicionRojo += 10;
        autoRojo.style.left = posicionRojo + 'px';
    } else if (tecla === 'l') {
        posicionAzul += 10;
        autoAzul.style.left = posicionAzul + 'px';

    }

    if (posicionRojo + anchoAuto >= anchoPista) {
        mensaje = '¡El auto rojo ganó la carrera!';
        mostrarGanador();
    } else if (posicionAzul + anchoAuto >= anchoPista) {
        mensaje = '¡El auto azul ganó la carrera!';
        mostrarGanador();
    }

    document.getElementById('mensaje').textContent = mensaje;
}

// Función para detener la carrera
function detenerCarrera() {
    window.removeEventListener('keyup', moverAutos);
}

// Función para mostrar el ganador y actualizar la puntuación
function mostrarGanador() {
    document.getElementById('ganador').style.display = 'block';
    puntuacion += 1;
    document.getElementById('puntuacion').textContent = 'Puntuación: ' + puntuacion;
    detenerCarrera();
}

// Inicializa el evento para mover los autos
window.addEventListener('keyup', moverAutos);
