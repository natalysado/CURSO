// Palabras para el juego
const words = [
    'californication', 'plataforma5', 'black', 'summer', 'flea', 'aeroplane',
    'peppers', 'unlimited', 'arcadium', 'love', 'getaway', 'stadium',
    'quixoticelixer', 'quarter', 'snow', 'dylan', 'zephyr', 'funky', 'chili'
  ];
  
  // Referencias a elementos del DOM
  const randomWordElement = document.getElementById('randomWord');
  const textInput = document.getElementById('text');
  const timeSpan = document.getElementById('timeSpan');
  const scoreSpan = document.getElementById('score');
  const endGameContainer = document.getElementById('end-game-container');
  
  // Variables del juego
  let palabraAleatoria;
  let time = 10;
  let score = 0;
  
  // Genera una palabra aleatoria
  function randomWords() {
    return words[Math.floor(Math.random() * words.length)];
  }
  
  // Añade palabra al DOM
  function addToDOM() {
    palabraAleatoria = randomWords();
    randomWordElement.innerText = palabraAleatoria;
  }
  
  // Inicializa el juego
  function initGame() {
    addToDOM();
    textInput.value = '';
    textInput.focus();
    score = 0;
    time = 10;
    updateScore();
    updateTime();
    startTimer();
  }
  
  // Actualiza el puntaje
  function updateScore() {
    scoreSpan.innerText = score;
  }
  
  // Actualiza el tiempo
  function updateTime() {
    timeSpan.innerText = `${time}s`;
  }
  
  // Inicia el temporizador
  function startTimer() {
    const timer = setInterval(() => {
      time--;
      updateTime();
  
      if (time === 0) {
        clearInterval(timer);
        gameOver();
      }
    }, 1000);
  }
  
  // Finaliza el juego
  function gameOver() {
    endGameContainer.innerHTML = `
      <h2>Se acabó el tiempo!</h2>
      <p>Tu puntaje final es ${score}</p>
      <button onclick="initGame()">Jugar de nuevo</button>
    `;
    endGameContainer.style.display = 'block';
  }
  
  // Evento de entrada de texto
  textInput.addEventListener('input', (e) => {
    const palabraIngresada = e.target.value;
  
    if (palabraIngresada === palabraAleatoria) {
      score++;
      time += 3;
      textInput.value = '';
      addToDOM();
      updateScore();
      updateTime();
    }
  });
  
  // Inicia el juego al cargar la página
  window.onload = initGame;
  