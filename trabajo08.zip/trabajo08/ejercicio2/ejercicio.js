// Almacenar la cantidad de días que estarás de viaje y el presupuesto máximo
let diasDeViaje = 10;
let presupuestoMaximo = 500; // Ejemplo: presupuesto máximo en tu moneda local

// Declarar la variable para el costo de comida
let comida;

// Estimar cuántas comidas tendrás en todo tu viaje
let comidasTotales = diasDeViaje * 3; // Estimando 3 comidas al día

// Calcular cuánto puedes gastar en cada comida
if (diasDeViaje > 0) {
    comida = presupuestoMaximo / comidasTotales;
} else {
    comida = 0;
}

// Mostrar el resultado en un alert
alert(`Podés gastar $${comida.toFixed(2)} en cada comida para que te alcance el dinero durante los ${diasDeViaje} días de viaje.`);
