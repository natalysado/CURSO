// Paso 4: Trabajar en tu archivo JS

// 1. Dar la bienvenida al sitio a los usuarios
alert('¡Bienvenido a mi primera página con JavaScript!');

// 2. Preguntar al usuario su nombre y guardarlo en una variable
let nombre = prompt('Por favor, ingresa tu nombre:');

// 3. Crear otro mensaje de saludo que incluya el nombre guardado en tu variable
alert(`Hola ${nombre}, bienvenido nuevamente.`);

// 4. Preguntar su edad y guardarla en una variable, luego mostrarla en la consola
let edad = prompt('¿Cuántos años tienes?');
console.log(`Tu edad es ${edad} años.`);

// 5. Mostrar un mensaje que incluya su nombre y edad
alert(`Tu nombre es ${nombre} y tienes ${edad} años.`);

// Mensaje con variables
let cumpleaños = '1 de enero';
let ciudad = 'Ciudad de México';
let ocupacion = 'Estudiante';
let pasatiempos = 'Escuchar música y leer libros';

// Usar console.log para escribir un párrafo que combine Strings con la información guardada en las Variables
console.log(`Mi nombre es ${nombre}, tengo ${edad} años. Nací el ${cumpleaños} en ${ciudad}. Actualmente soy ${ocupacion} y mis pasatiempos son ${pasatiempos}.`);

// Crear múltiples Variables en una única línea de código
let otroNombre = 'Ana', otraEdad = 28, otraCiudad = 'Madrid';

// Cantidad de caracteres
let texto = prompt('Ingresa un texto breve:');
console.log(`El texto ingresado tiene ${texto.length} caracteres.`);

// Calculadora De Edad
let edadUsuario = prompt('¿Cuántos años tienes?');
let dias = edadUsuario * 365; // Considerando que un año tiene 365 días
console.log(`Tu edad de ${edadUsuario} años representa aproximadamente ${dias} días.`);

// Suma De Valores
let num1, num2, resultado;
num1 = parseInt(prompt('Ingresa el primer número:'));
num2 = parseInt(prompt('Ingresa el segundo número:'));
resultado = num1 + num2;
console.log(`La suma de ${num1} y ${num2} es ${resultado}.`);
