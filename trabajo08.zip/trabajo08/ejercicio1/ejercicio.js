
// Almacenar la edad actual y la edad máxima estimada
let edadActual = 30;
let edadMaxima = 80;

// Declarar el nombre del snack favorito y estimar cuántos se consumen por día
let snackFavorito = 'galletas';
let snacksPorDia = 2; // Ejemplo: se consumen 2 galletas por día

// Calcular cuántos snacks se consumirán por el resto de la vida
let añosRestantes = edadMaxima - edadActual;
let snacksPorVida = añosRestantes * 365 * snacksPorDia;

// Mostrar el resultado en un alert
alert(`Necesitarás ${snacksPorVida} ${snackFavorito} para que te alcancen hasta los ${edadMaxima} años.`);

// Calcular el gasto estimado en snacks
let precioPorUnidad = 1.5; // Ejemplo: precio por unidad de galleta
let gastoTotal = snacksPorVida * precioPorUnidad;

// Mostrar el gasto total en un alert
alert(`En total, gastarás aproximadamente $${gastoTotal.toFixed(2)} en ${snackFavorito} durante el resto de tu vida.`);


